/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_236()
{
    return 2425374954U;
}

unsigned addval_216(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_495(unsigned x)
{
    return x + 2496104776U;
}

void setval_178(unsigned *p)
{
    *p = 2425393240U;
}

unsigned addval_241(unsigned x)
{
    return x + 3284633944U;
}

void setval_166(unsigned *p)
{
    *p = 2425393240U;
}

void setval_307(unsigned *p)
{
    *p = 2455271863U;
}

unsigned getval_350()
{
    return 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_194(unsigned *p)
{
    *p = 3532964489U;
}

void setval_125(unsigned *p)
{
    *p = 3464585329U;
}

unsigned addval_304(unsigned x)
{
    return x + 2428668189U;
}

unsigned getval_296()
{
    return 3286272328U;
}

unsigned getval_474()
{
    return 2425409921U;
}

unsigned getval_370()
{
    return 2496760217U;
}

unsigned getval_377()
{
    return 2429471002U;
}

unsigned getval_336()
{
    return 2425406088U;
}

unsigned addval_428(unsigned x)
{
    return x + 3381972617U;
}

unsigned getval_431()
{
    return 3381973385U;
}

unsigned addval_257(unsigned x)
{
    return x + 3676360321U;
}

void setval_252(unsigned *p)
{
    *p = 2425409161U;
}

unsigned getval_397()
{
    return 3682128265U;
}

void setval_437(unsigned *p)
{
    *p = 2430634313U;
}

void setval_485(unsigned *p)
{
    *p = 3224949133U;
}

void setval_133(unsigned *p)
{
    *p = 3536110217U;
}

void setval_232(unsigned *p)
{
    *p = 3286272264U;
}

unsigned addval_295(unsigned x)
{
    return x + 2428676428U;
}

void setval_171(unsigned *p)
{
    *p = 3281043977U;
}

unsigned addval_446(unsigned x)
{
    return x + 2428668400U;
}

void setval_383(unsigned *p)
{
    *p = 3373846153U;
}

void setval_401(unsigned *p)
{
    *p = 3281047945U;
}

unsigned addval_450(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_111(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_209()
{
    return 3286273352U;
}

void setval_340(unsigned *p)
{
    *p = 2497743176U;
}

unsigned addval_107(unsigned x)
{
    return x + 3678982537U;
}

unsigned getval_453()
{
    return 3229929865U;
}

unsigned addval_227(unsigned x)
{
    return x + 3281047177U;
}

unsigned addval_179(unsigned x)
{
    return x + 3767093423U;
}

void setval_199(unsigned *p)
{
    *p = 3285108997U;
}

unsigned addval_293(unsigned x)
{
    return x + 3525362185U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
